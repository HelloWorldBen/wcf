﻿using System.ServiceModel;

namespace HelloProjectClient
{
    [ServiceContract]
    public interface IHelloWorld
    {
        [OperationContract]
        string HelloWorld();

        [OperationContract]
        void WriteMe(string text);
    }
}