﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace HelloProjectClient
{
    class Program
    {
        static void Main(string[] args)
        {

            var binding = new NetTcpBinding(SecurityMode.None)
            {
                PortSharingEnabled = true
            };

            Console.WriteLine("Press enter when the service is opened.");
            Console.ReadLine();


            var endPoint = new EndpointAddress("net.tcp://127.0.0.1:1234/HelloWorldService/IHelloWorld/");
           
          
            var channel = new ChannelFactory<IHelloWorld>(binding, endPoint);
            var client = channel.CreateChannel();

            try
            {
                Console.WriteLine("Invoking HelloWorld on TcpService.");
                Console.Write(client.HelloWorld());
                Console.WriteLine("Successful.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
            }

            Console.WriteLine("Press enter to quit.");
            Console.ReadLine();
        }
    }

    
}
