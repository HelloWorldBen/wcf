﻿using System.ServiceModel;

namespace HelloProject
{
    [ServiceContract]
    public interface IHelloWorld
    {
        [OperationContract]
        string HelloWorld();

        [OperationContract]
        void WriteMe(string text);
    }
}