﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace HelloProject
{
    class Program
    {
        static void Main()
        {
            var netTcpBinding = new NetTcpBinding(SecurityMode.None)
            {
                PortSharingEnabled = true
            };

            var netTcpAdddress = new Uri("net.tcp://127.0.0.1:1234/HelloWorldService/");

            var tcpHost = new ServiceHost(typeof(HelloWorldService), netTcpAdddress);
            tcpHost.AddServiceEndpoint(typeof(IHelloWorld), netTcpBinding, "IHelloWorld");

            tcpHost.Open();
            Console.WriteLine($"tcpHost is {tcpHost.State}.  Press enter to close.");

            Console.ReadLine();
            tcpHost.Close();
        }
    }


    public class HelloWorldService : IHelloWorld
    {
        public string HelloWorld()
        {
           return "Hello World!";
        }

        public void WriteMe(string text)
        {
            Console.WriteLine($"WriteMe: {text}");
        }
    }
}

